﻿using System;
namespace Kerstboom
{
	public interface IKerstBoom
	{
        void Decorate();
    }
}

