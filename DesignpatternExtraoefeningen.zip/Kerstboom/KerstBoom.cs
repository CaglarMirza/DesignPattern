﻿using System;
namespace Kerstboom
{
	public class KerstBoom :IKerstBoom
	{
        public void Decorate()
        {
            Console.WriteLine("Een kerstboom met:");
        }
    }
}

