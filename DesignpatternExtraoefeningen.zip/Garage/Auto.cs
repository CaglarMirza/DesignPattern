﻿using System;
namespace Garage
{
	public class Auto:IAuto
	{
	public decimal GetPrijs() { return 30000; }
	}
}

