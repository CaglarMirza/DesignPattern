﻿using System;
namespace Garage
{
	public interface IAuto
	{
        decimal GetPrijs();
    }
}

