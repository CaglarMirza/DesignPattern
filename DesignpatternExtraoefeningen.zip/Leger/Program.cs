﻿using Leger;
//namespace Leger;

Legerac leger1 = new Legerac();

Vijand vijand = new Vijand();

leger1.Attach(vijand);


leger1.StartFighting();
leger1.InvokePeace();