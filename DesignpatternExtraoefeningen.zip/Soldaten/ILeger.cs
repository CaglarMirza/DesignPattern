﻿using System;
namespace Soldaten
{
	public interface ILeger
	{
        void TrekTenStrijde();
    }
}

