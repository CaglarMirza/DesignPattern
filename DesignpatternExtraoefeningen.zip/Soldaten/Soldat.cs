﻿using System;
namespace Soldaten
{
	public class Soldat:ILeger
	{
		public void TrekTenStrijde()
		{
			Console.WriteLine("Soldat ten strijde");
		}
	}
}

