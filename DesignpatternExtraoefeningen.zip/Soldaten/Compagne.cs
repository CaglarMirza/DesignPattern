﻿using System;
namespace Soldaten
{
	public class Compagne:Groep
	{
		
	}
}

