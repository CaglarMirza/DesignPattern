﻿using System;
namespace Soldaten
{
	public class Peloton:Groep
	{
	
	}
}

