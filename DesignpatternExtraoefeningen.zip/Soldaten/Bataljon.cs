﻿using System;
namespace Soldaten
{
	public class Bataljon :Groep
	{
		
	}
}

