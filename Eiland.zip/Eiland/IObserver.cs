﻿using System;
namespace Eiland
{
    public interface IObserver
    {
        void ReageerVulkaanuitbarsting(EiLand eiLand);

    }
}

